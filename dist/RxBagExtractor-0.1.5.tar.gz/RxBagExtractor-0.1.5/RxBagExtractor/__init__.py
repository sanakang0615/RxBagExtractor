from .extractor import extractor
print("RxBagExtractor is being initialized")